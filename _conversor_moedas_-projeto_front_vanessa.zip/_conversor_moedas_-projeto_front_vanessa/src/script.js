var valorEuro = 30;
var cotacaoEuro = 5.25;
var valorEmReal = valorEuro * cotacaoEuro;
var valorPessoal = "Ola pessoal o valor em real e R$";
valorEmReal = valorEmReal.toFixed(2);

alert(valorPessoal + valorEmReal);
