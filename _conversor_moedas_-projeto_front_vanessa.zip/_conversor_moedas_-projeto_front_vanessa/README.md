# _Conversor_moedas_ projeto_front_vanessa

A Pen created on CodePen.io. Original URL: [https://codepen.io/vanefati/pen/rNPzVrX](https://codepen.io/vanefati/pen/rNPzVrX).

Efetuar o calculo de conversão do valor da moeda em Euro para o valor da moeda em Real.